import { InputChoice } from './input-choice';
import { InputGroup } from './input-group';
/**
 * @deprecated Use InputChoice instead
 */
export interface Item extends InputChoice {
}
/**
 * @deprecated Use InputChoice instead
 */
export interface Choice extends InputChoice {
}
/**
 * @deprecated Use InputGroup instead
 */
export interface Group extends InputGroup {
}
