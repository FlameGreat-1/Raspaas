export interface HTMLContentProps {
    content: string;
    parentElement?: string;
}
export declare function HTMLElement(props: HTMLContentProps): import("preact").VNode<any>;
