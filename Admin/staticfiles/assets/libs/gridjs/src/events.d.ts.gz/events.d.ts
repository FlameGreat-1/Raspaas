import { TableEvents } from './view/table/events';
import { ContainerEvents } from './view/events';
export type GridEvents = ContainerEvents & TableEvents;
