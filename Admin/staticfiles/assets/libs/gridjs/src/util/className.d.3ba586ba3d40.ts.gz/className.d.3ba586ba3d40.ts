import { JSXInternal } from 'preact/src/jsx';
export declare function className(...args: string[]): string;
export declare function classJoin(...classNames: (undefined | string | JSXInternal.SignalLike<string>)[]): string;
