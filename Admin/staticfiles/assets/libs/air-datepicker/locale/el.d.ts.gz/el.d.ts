declare module 'air-datepicker/locale/el' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const el: AirDatepickerLocale;

    export default el;
}
