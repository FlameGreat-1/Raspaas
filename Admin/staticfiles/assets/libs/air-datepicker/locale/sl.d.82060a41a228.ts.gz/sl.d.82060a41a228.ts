declare module 'air-datepicker/locale/sl' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const sl: AirDatepickerLocale;

    export default sl;
}
