declare module 'air-datepicker/locale/nb' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const nb: AirDatepickerLocale;

    export default nb;
}
