declare module 'air-datepicker/locale/en' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const en: AirDatepickerLocale;

    export default en;
}
