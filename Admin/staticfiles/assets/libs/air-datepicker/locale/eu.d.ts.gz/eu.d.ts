declare module 'air-datepicker/locale/eu' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const eu: AirDatepickerLocale;

    export default eu;
}
