declare module 'air-datepicker/locale/ca' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const ca: AirDatepickerLocale;

    export default ca;
}
