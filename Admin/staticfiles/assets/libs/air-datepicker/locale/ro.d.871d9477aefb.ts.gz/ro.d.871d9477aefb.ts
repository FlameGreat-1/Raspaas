declare module 'air-datepicker/locale/ro' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const ro: AirDatepickerLocale;

    export default ro;
}
