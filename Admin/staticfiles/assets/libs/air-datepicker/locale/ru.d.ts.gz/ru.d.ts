declare module 'air-datepicker/locale/ru' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const ru: AirDatepickerLocale;

    export default ru;
}
