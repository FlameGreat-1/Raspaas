declare module 'air-datepicker/locale/si' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const si: AirDatepickerLocale;

    export default si;
}
