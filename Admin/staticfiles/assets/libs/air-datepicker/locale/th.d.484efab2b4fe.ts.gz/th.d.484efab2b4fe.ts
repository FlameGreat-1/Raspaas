declare module 'air-datepicker/locale/th' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const th: AirDatepickerLocale;

    export default th;
}
