declare module 'air-datepicker/locale/ja' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const ja: AirDatepickerLocale;

    export default ja;
}
