declare module 'air-datepicker/locale/bg' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const bg: AirDatepickerLocale;

    export default bg;
}
