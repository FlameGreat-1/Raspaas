declare module 'air-datepicker/locale/pt-BR' {
    import {AirDatepickerLocale} from 'air-datepicker';
    const ptBr: AirDatepickerLocale;

    export default ptBr;
}
